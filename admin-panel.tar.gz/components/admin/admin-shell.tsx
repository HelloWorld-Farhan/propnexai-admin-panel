"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Bot,
  Building2,
  LayoutDashboard,
  LifeBuoy,
  LogOut,
  Phone,
  ClipboardList,
  Briefcase,
  Menu,
  X,
  Server,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { AdminNotifications } from "./notification-bell";
import { useState } from "react";

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/companies", label: "Companies", icon: Building2 },
  { href: "/channels", label: "Form Info", icon: ClipboardList },
  { href: "/numbers", label: "Numbers", icon: Phone },
  { href: "/agents", label: "Agent Library", icon: Bot },
  { href: "/jobs", label: "Jobs", icon: Briefcase }, // Added Jobs
  { href: "/infra-costs", label: "Infra Costs", icon: Server },
  { href: "/support", label: "Support", icon: LifeBuoy },
];

export function AdminShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  }

  return (
    <div className="flex min-h-screen bg-background flex-col md:flex-row">
      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between p-4 border-b border-border bg-sidebar">
        <div className="flex items-center gap-2">
          <p className="text-sm font-bold uppercase tracking-widest text-primary">PropNex Admin</p>
        </div>
        <div className="flex items-center gap-4">
          <AdminNotifications />
          <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Sidebar */}
      <aside className={cn(
        "flex w-full md:w-56 shrink-0 flex-col border-r border-sidebar-border bg-sidebar transition-all",
        mobileMenuOpen ? "block" : "hidden md:flex"
      )}>
        <div className="hidden md:block border-b border-sidebar-border px-4 py-5">
          <p className="text-xs font-medium uppercase tracking-widest text-primary">
            PropNex
          </p>
          <p className="text-sm text-sidebar-foreground">Admin Panel</p>
        </div>
        <nav className="flex flex-1 flex-col gap-1 p-3">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active =
              pathname === item.href || pathname.startsWith(`${item.href}/`);
            return (
              <Link
                key={item.href}
                href={item.href}
                prefetch={true}
                onClick={() => setMobileMenuOpen(false)}
                className={cn(
                  "flex items-center gap-2 rounded-md px-3 py-2 text-sm transition-colors",
                  active
                    ? "bg-sidebar-accent text-foreground"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-foreground",
                )}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="border-t border-sidebar-border p-3">
          <Button
            variant="ghost"
            className="w-full justify-start gap-2 text-sidebar-foreground"
            onClick={handleLogout}
          >
            <LogOut className="h-4 w-4" />
            Log out
          </Button>
        </div>
      </aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="hidden md:flex h-14 items-center justify-between border-b border-border px-6">
          <p className="text-sm text-muted-foreground">
            Platform administration
          </p>
          <AdminNotifications />
        </header>
        <main className="flex-1 overflow-auto p-4 md:p-6">{children}</main>
      </div>
    </div>
  );
}
