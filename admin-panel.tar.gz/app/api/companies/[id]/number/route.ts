import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { generatePublicId, allocatePhoneNumberEntityId } from "@/src/server/lib/public-id";

// PATCH — update the existing (first) assigned number
export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const body = await req.json();

    if (!body.newNumber) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    const numTrimmed = body.newNumber.replace(/[\s-()]/g, "").trim();

    // Look for an existing agentUrl for this DID globally
    const existingGlobalNumber = await prisma.phoneNumber.findFirst({
      where: { number: numTrimmed, agentUrl: { not: null } },
      select: { agentUrl: true }
    });

    // Update the phone number associated with this company
    const updated = await prisma.phoneNumber.updateMany({
      where: { companyId: id },
      data: { 
        number: numTrimmed,
        ...(existingGlobalNumber?.agentUrl ? { agentUrl: existingGlobalNumber.agentUrl } : {})
      },
    });

    if (updated.count === 0) {
      return NextResponse.json({ error: "No phone number found for this sub-company" }, { status: 404 });
    }

    // Ensure company is active so dashboard unlocks
    await prisma.company.update({
      where: { id },
      data: { status: "ACTIVE" } as any,
    });

    await prisma.systemEvent.create({
      data: {
        companyId: id,
        type: "NUMBER_ASSIGNED",
        title: "Number Re-assigned",
        message: `Phone number ${numTrimmed} was re-assigned to the company.`,
      }
    }).catch(console.error);

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error("[EDIT_SUB_COMPANY_NUMBER_ERROR]", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// POST — add an additional phone number to a company
export async function POST(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const body = await req.json();

    if (!body.newNumber || !body.newNumber.trim()) {
      return NextResponse.json({ error: "Phone number is required" }, { status: 400 });
    }

    // Verify company exists
    const company = await prisma.company.findUnique({
      where: { id },
      select: { id: true, name: true, parentCompanyId: true, phoneNumbers: { select: { id: true, number: true, direction: true, channels: true } } },
    });

    if (!company) {
      return NextResponse.json({ error: "Company not found" }, { status: 404 });
    }

    // Check not already assigned
    const numTrimmed = body.newNumber.replace(/[\s-()]/g, "").trim();
    const existingNumber = company.phoneNumbers.find((p: any) => p.number === numTrimmed);
    if (existingNumber) {
      const newDirection = (existingNumber.direction && body.direction && existingNumber.direction !== body.direction) 
        ? "BOTH" 
        : (existingNumber.direction || body.direction || "BOTH");
      const newChannels = body.channels !== undefined ? body.channels : existingNumber.channels;
      
      await prisma.phoneNumber.update({
        where: { id: existingNumber.id },
        data: { direction: newDirection, channels: newChannels }
      });
      
      // Ensure company is active so dashboard unlocks
      await prisma.company.update({
        where: { id },
        data: { status: "ACTIVE" } as any,
      });

      await prisma.systemEvent.create({
        data: {
          companyId: id,
          type: "NUMBER_ASSIGNED",
          title: "Number Settings Updated",
          message: `Phone number ${numTrimmed} direction/channels were updated.`,
        }
      }).catch(console.error);
      
      return NextResponse.json({ success: true, updated: true });
    }

    // Generate required IDs
    const phoneNumberId = await allocatePhoneNumberEntityId(prisma as any, id);
    const publicId = generatePublicId(company.name.substring(0, 3).toUpperCase(), "UNASSIGNED", phoneNumberId);

    // Look for an existing agentUrl for this DID globally
    const existingGlobalNumber = await prisma.phoneNumber.findFirst({
      where: { number: numTrimmed, agentUrl: { not: null } },
      select: { agentUrl: true }
    });

    // Create the new phone number record
    const created = await prisma.phoneNumber.create({
      data: {
        number: numTrimmed,
        companyId: id,
        status: "ACTIVE",
        provider: "PROPNEX",
        phoneNumberId,
        publicId,
        assignedParentTenantId: company.parentCompanyId,
        direction: body.direction || null,
        channels: body.channels !== undefined ? body.channels : null,
        agentUrl: existingGlobalNumber?.agentUrl || null,
      } as any,
    });

    // Ensure company is active so dashboard unlocks
    await prisma.company.update({
      where: { id },
      data: { status: "ACTIVE" } as any,
    });

    await prisma.systemEvent.create({
      data: {
        companyId: id,
        type: "NUMBER_ASSIGNED",
        title: "Number Assigned",
        message: `Phone number ${numTrimmed} was assigned to the company.`,
      }
    }).catch(console.error);

    // Webhook and Resolution Logic
    try {
      const companyWithMembers = await prisma.company.findUnique({
        where: { id },
        include: { members: { include: { user: true } }, parentCompany: true }
      });
      if (companyWithMembers && companyWithMembers.members.length > 0) {
        const user = companyWithMembers.members[0].user;
        if (user && user.email) {
          const isSubCompany = !!companyWithMembers.parentCompanyId;
          const webhookUrl = "https://script.google.com/macros/s/AKfycbz2zj_l7vcmiPZKuYqEVdso0apyW3aDJZZWTVTJ1jRrQr8PLGZIH_TzRpTLFskphIwgDQ/exec";
          
          fetch(webhookUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              type: isSubCompany ? "number_assigned_subcompany" : "number_assigned",
              email: user.email,
              name: user.firstName ? `${user.firstName} ${user.lastName}`.trim() : user.email.split("@")[0],
              assignedNumber: numTrimmed,
              direction: body.direction || "GENERAL",
              subcompanyName: isSubCompany ? companyWithMembers.name : undefined
            }),
          }).catch(err => console.error("Failed to send number assignment webhook:", err));
          
          await prisma.supportRequest.updateMany({
            where: {
              companyId: id,
              reason: "OTHER",
              message: { contains: "Number Assignment Request" },
              status: "NEW"
            },
            data: { status: "RESOLVED" }
          });
        }
      }
    } catch (e) {
      console.error("Webhook/SupportRequest resolution error:", e);
    }

    return NextResponse.json({ success: true, phoneNumber: created });
  } catch (error: any) {
    console.error("[ADD_COMPANY_NUMBER_ERROR]", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
